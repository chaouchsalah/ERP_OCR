A Pen created at CodePen.io. You can find this one at https://codepen.io/Keyon/pen/BKbMdE.

 If you ask yourself "Why should I need this?" the answer is:
                    
'Cause this can be cool at Cloud Storage, imagine to enter your Google Drive or DropBox and have a mini computer, with desktop, windows and other.
It isn't more difficult to use, so why not?
                    
Anyway, this is only a preview to show my skill level (19/05/16), maybe someone who want to create an OS can use this for an idea.